package com.IONA.TowerDefense.model.units.interfaces;

import java.awt.*;

public interface Targetable {
    Point getPosition();

    Rectangle getHitbox();
}
