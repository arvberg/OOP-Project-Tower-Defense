package com.IONA.TowerDefense.view.units.enemies;

import com.IONA.TowerDefense.view.Drawable;

public sealed interface DrawableEnemy extends Drawable permits EnemyBasicDrawer,
    EnemyFastDrawer, EnemyTankyDrawer
{


}
