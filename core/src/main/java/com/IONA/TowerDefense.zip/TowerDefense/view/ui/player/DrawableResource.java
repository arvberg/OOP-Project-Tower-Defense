package com.IONA.TowerDefense.view.ui.player;

import com.IONA.TowerDefense.view.Drawable;

public sealed interface DrawableResource extends Drawable permits MoneyDrawer,HpDrawer {
}
