package com.IONA.TowerDefense.model.units.interfaces;

public interface InputListener {
    void onButtonClicked();
    void onInvalidClick();
}
