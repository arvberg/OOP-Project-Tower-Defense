package com.IONA.TowerDefense.model;

public enum Direction {
    NORTH,
    EAST,
    SOUTH,
    WEST
}
