package com.IONA.TowerDefense.model.units.interfaces;

public interface AttackListener {
    void onProjectileFired();
    void onPulseActivated();
}
