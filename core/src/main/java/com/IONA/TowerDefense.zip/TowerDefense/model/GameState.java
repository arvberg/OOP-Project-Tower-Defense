package com.IONA.TowerDefense.model;

public enum GameState {
    TITLE,
    START,
    RUNNING,
    PAUSED,
    GAME_OVER
}
