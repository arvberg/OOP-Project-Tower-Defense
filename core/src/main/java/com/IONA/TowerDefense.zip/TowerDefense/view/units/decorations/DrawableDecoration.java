package com.IONA.TowerDefense.view.units.decorations;

import com.IONA.TowerDefense.view.Drawable;

public sealed interface DrawableDecoration extends Drawable permits CoreDrawer{

}
