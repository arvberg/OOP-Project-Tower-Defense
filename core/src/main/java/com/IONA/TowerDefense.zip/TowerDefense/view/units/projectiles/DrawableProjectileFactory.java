package com.IONA.TowerDefense.view.units.projectiles;

import com.IONA.TowerDefense.model.units.Unit;
import com.IONA.TowerDefense.model.units.enemies.Enemy;
import com.IONA.TowerDefense.model.units.enemies.EnemyBasic;
import com.IONA.TowerDefense.model.units.projectiles.Projectile;
import com.IONA.TowerDefense.view.units.enemies.DrawableEnemy;
import com.IONA.TowerDefense.view.units.enemies.EnemyBasicDrawer;

public class DrawableProjectileFactory {

    private DrawableProjectileFactory(){}

    // TILLFÄLLIGT Unit, ska senare vara Projectile och case ProjectileBasic
    public static DrawableProjectile create(Unit projectile){
        return switch (projectile){
            case Projectile p -> new ProjectileBasicDrawer(p);
            //case EnemyFast e   -> new EnemyFastDrawer(e);
            //case EnemyTanky e   -> new EnemyTankDrawer(e);
            default -> throw new IllegalStateException("Unexpected value: " + projectile);
        };
    }
}
