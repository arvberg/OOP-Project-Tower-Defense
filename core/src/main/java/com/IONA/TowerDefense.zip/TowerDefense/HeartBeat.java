package com.IONA.TowerDefense;

public class HeartBeat {
    public static float delta;
}
