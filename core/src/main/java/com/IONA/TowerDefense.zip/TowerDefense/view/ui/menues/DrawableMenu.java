package com.IONA.TowerDefense.view.ui.menues;

import com.IONA.TowerDefense.view.Drawable;
import com.IONA.TowerDefense.view.ui.menues.TowerMenuDrawer;

public sealed interface DrawableMenu extends Drawable permits TowerMenuDrawer,
    InfoMenuDrawer, UpgradeMenuDrawer
{


}
