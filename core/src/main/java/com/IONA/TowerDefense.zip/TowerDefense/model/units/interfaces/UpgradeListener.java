package com.IONA.TowerDefense.model.units.interfaces;

public interface UpgradeListener {
    void onUpgrade();
}
